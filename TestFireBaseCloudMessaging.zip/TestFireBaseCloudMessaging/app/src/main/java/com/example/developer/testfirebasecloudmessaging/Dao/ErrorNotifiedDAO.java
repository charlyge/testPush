package com.example.developer.testfirebasecloudmessaging.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.developer.testfirebasecloudmessaging.Entities.ErrorNotified;

import java.util.List;

@Dao
public interface ErrorNotifiedDAO {

    @Query("Select * from ErrorNotified order by id desc" )
    List<ErrorNotified> getAllErrorLogs();

    @Delete
    void deleteErrorLogs(ErrorNotified errorNotified);

    @Insert
    void InsertErrorLogs(ErrorNotified errorNotified);

    @Query("DELETE FROM ErrorNotified")
    void DeleteAll();

    @Query("Select * from ErrorNotified where id =:id" )
    List<ErrorNotified> getAllErrorLogs(int id);

    @Query("Select * from ErrorNotified where severIp =:serverip" )
    List<ErrorNotified> getAllSeverIp(String serverip);

    @Query("Select * from ErrorNotified where applicationName =:appName" )
    List<ErrorNotified> getAllSeverName(String appName);





}
