package com.example.developer.testfirebasecloudmessaging.Model;

public class ErrorLog {
    private int serverIp;
    private String errorCode;
    private String errorDescription;
    private String errorSeverity;
    private String applicationName;

    public ErrorLog( int serverIp, String errorCode,String errorDescription, String errorSeverity,String applicationName){
        this.applicationName=applicationName;
        this.errorCode =errorCode;
        this.errorSeverity  =errorSeverity;
        this.errorDescription = errorDescription;
        this.serverIp = serverIp;

    }

    public int getServerIp() {
        return serverIp;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public String getErrorSeverity() {
        return errorSeverity;
    }

    public String getErrorDescription() {
        return errorDescription;
    }
}
