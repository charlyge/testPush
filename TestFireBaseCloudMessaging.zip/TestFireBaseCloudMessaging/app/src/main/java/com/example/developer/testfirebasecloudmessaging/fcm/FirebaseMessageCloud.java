package com.example.developer.testfirebasecloudmessaging.fcm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.example.developer.testfirebasecloudmessaging.Database.AppDatabase;
import com.example.developer.testfirebasecloudmessaging.Database.AppExecutors;
import com.example.developer.testfirebasecloudmessaging.Entities.AppName;
import com.example.developer.testfirebasecloudmessaging.Entities.ErrorNotified;
import com.example.developer.testfirebasecloudmessaging.Entities.ServerIp;
import com.example.developer.testfirebasecloudmessaging.R;
import com.example.developer.testfirebasecloudmessaging.ViewErrorActivity;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.Trigger;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Date;
import java.util.Map;

public class FirebaseMessageCloud extends FirebaseMessagingService {
    private static FirebaseJobDispatcher dispatcher;
    private String serverIpData;
    private String errorDescription;
    private String errorSeverity;
    private String errorCode;
    private String applicationName;
    public static final String CHANNEL_ID = "CHANNEL_ID";
    public static final int NOTIFICATIONID = 66;
    public static final String SERVER_IP = "serverIp";
    public static final String ERROR_DESCRIPTION = "errorDescription";
    public static final String ERROR_SEVERITY = "errorSeverity";
    public static final String APPLICATION_NAME = "applicationName";
    public static final String ERROR_CODE = "errorcode";
    private static final String REMINDER_JOB_TAG = "job Tag";





    // Payloads enters from firebase
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // Toast.makeText(this,"From: " + remoteMessage.getFrom(),Toast.LENGTH_LONG).show();
        Log.d("remoteMessageTag", "From: " + remoteMessage.getFrom());
        Map<String, String> data = remoteMessage.getData();
        Log.d("remoteMessageTag", "Message data payload: " + data);

        //Schedules a reminder job
        ScheduleJob(getApplicationContext());

        //makes a notification for the user
        sendNotification(data);

        // Inserts Data into Database
       insertDataIntoDbCheckIngServerIp(getApplicationContext());

    }


    private void insertDataIntoDbCheckIngServerIp(final Context context) {

        final ServerIp ServerIp = new ServerIp(serverIpData, "2");


        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
            @Override
            public void run() {

                //Checks if ServerIp  and App Name already exist before inserting
             int checkserverIp = AppDatabase.getInstance(context).serverIpDAO().getServerIdFromName(serverIpData);
             int checkAppIp = AppDatabase.getInstance(context).appNameDAO().getAppIdFromName(applicationName);

                    if(checkserverIp<1){
                     checkserverIp= (int) AppDatabase.getInstance(context).serverIpDAO().insertServerIP(ServerIp);

                    }
                    if(checkAppIp<1){
                        checkAppIp = (int) AppDatabase.getInstance(context).appNameDAO().insertAppName( new AppName(checkserverIp,applicationName,"5"));

                    }
                Date date = new Date();

                ErrorNotified errorNotified = new ErrorNotified(checkserverIp, checkAppIp, errorCode, errorDescription, errorSeverity,applicationName,serverIpData,date);
                AppDatabase.getInstance(context).errorNotifiedDAO().InsertErrorLogs(errorNotified);


            }
        });


    }

    private static void ScheduleJob(@NonNull final Context context) {

        dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(context));
        Job job = dispatcher.newJobBuilder()
                .setService(MyJobservice.class)
                .setTag("JOB_TAG")
                .setLifetime(Lifetime.FOREVER)
                .setRecurring(true)
                .setTrigger(Trigger.executionWindow(0, 60))
                .setReplaceCurrent(true)
                .build();
        dispatcher.schedule(job);

    }

    private void updateUi(Map<String, String> data, Intent intent) {
        serverIpData = data.get(SERVER_IP);
        errorDescription = data.get(ERROR_DESCRIPTION);
        errorSeverity = data.get(ERROR_SEVERITY);
        applicationName = data.get(APPLICATION_NAME);
        errorCode = data.get(ERROR_CODE);
        intent.putExtra(SERVER_IP, serverIpData);
        intent.putExtra(ERROR_DESCRIPTION, errorDescription);
        intent.putExtra(ERROR_SEVERITY, errorSeverity);
        intent.putExtra(APPLICATION_NAME, applicationName);

    }

    private void sendNotification(Map<String, String> data) {
        Uri notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Intent intent = new Intent(this, ViewErrorActivity.class);
        updateUi(data, intent);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notifications_active_black_24dp)
                .setContentTitle("Server Error Alert")
                .setContentIntent(pendingIntent)
                .setDefaults(Notification.DEFAULT_VIBRATE)
                .setDefaults(Notification.DEFAULT_SOUND)
                .setSound(notificationUri)
                .setContentText("Text")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Error Notification";
            // String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);

            notificationManager.createNotificationChannel(channel);

        }

        notificationManager.notify(NOTIFICATIONID, builder.build());


    }

    public static void cancelDispatcher() {
        if (dispatcher != null) {
            dispatcher.cancel("JOB_TAG");
        }

    }
}
