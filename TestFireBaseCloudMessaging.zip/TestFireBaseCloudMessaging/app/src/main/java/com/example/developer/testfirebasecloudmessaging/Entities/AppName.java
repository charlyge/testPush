package com.example.developer.testfirebasecloudmessaging.Entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

@Entity
@ForeignKey(entity= ServerIp.class,parentColumns = "sid",childColumns = "Appid")
public class AppName {

    @PrimaryKey(autoGenerate = true)
    private int Appid;
    private String ApplicationName;
    private String ApplicationStatus;
    private int ServerIP;

    public AppName(int Appid, int ServerIP, String ApplicationName, String ApplicationStatus){
   this.Appid =Appid;
   this.ApplicationName =ApplicationName;
   this.ApplicationStatus = ApplicationStatus;
   this.ServerIP = ServerIP;

    }


    @Ignore
    public AppName(int ServerIp , String ApplicationName, String ApplicationStatus){
        this.ApplicationName =ApplicationName;
        this.ApplicationStatus = ApplicationStatus;
        this.ServerIP =ServerIp;

    }

    public int getAppid() {
        return Appid;
    }

    public String getApplicationName() {
        return ApplicationName;
    }

    public String getApplicationStatus() {
        return ApplicationStatus;
    }

    public int getServerIP() {
        return ServerIP;
    }
}
