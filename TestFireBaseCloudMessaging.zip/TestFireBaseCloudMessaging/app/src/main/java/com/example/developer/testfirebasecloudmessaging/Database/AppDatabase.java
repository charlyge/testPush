package com.example.developer.testfirebasecloudmessaging.Database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.developer.testfirebasecloudmessaging.Dao.AppNameDAO;
import com.example.developer.testfirebasecloudmessaging.Dao.ErrorNotifiedDAO;
import com.example.developer.testfirebasecloudmessaging.Dao.ServerIpDAO;
import com.example.developer.testfirebasecloudmessaging.Entities.AppName;
import com.example.developer.testfirebasecloudmessaging.Entities.ErrorNotified;
import com.example.developer.testfirebasecloudmessaging.Entities.ServerIp;

@Database(entities = {AppName.class,ErrorNotified.class,ServerIp.class}, version = 1,exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase sInstance;
    private static final Object LOCK = new Object();
    private static final String DATABASE_NAME = "instant Error";


    public static AppDatabase getInstance(Context context) {

        if(sInstance==null){
            synchronized (LOCK){
                sInstance = Room.databaseBuilder(context.getApplicationContext(),AppDatabase.class,DATABASE_NAME)
                        .build();
            }

        }
        return sInstance;
    }

    public abstract AppNameDAO appNameDAO();
    public abstract ErrorNotifiedDAO errorNotifiedDAO();
    public abstract ServerIpDAO serverIpDAO();
}
