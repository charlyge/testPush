package com.example.developer.testfirebasecloudmessaging.Entities;


import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

import java.util.Date;

@Entity(
        indices = {@Index(value = "applicationId"),@Index(value = "serverId")},
       foreignKeys = {@ForeignKey (entity = ServerIp.class, parentColumns = "sid", childColumns = "serverId"),
        @ForeignKey(entity = AppName.class, parentColumns = "Appid", childColumns = "applicationId")})

public class ErrorNotified {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int serverId;
    private String errorCode;
    private String errorDescription;
    private String errorSeverity;
    private int applicationId;
    private String applicationName;
    private String severIp;
    private Date date;

    @Ignore
    public ErrorNotified(int serverId,  int applicationId,String errorCode, String errorDescription, String errorSeverity,
    String applicationName,
            String severIp,Date date
    ){
        this.applicationId=applicationId;
        this.errorCode =errorCode;
        this.errorSeverity  =errorSeverity;
        this.errorDescription = errorDescription;
        this.serverId = serverId;
        this.applicationName = applicationName;
        this.severIp = severIp;
        this.date = date;

    }

    public ErrorNotified(int id, int serverId, int applicationId ,String errorCode, String errorDescription, String errorSeverity
    ,String applicationName, String severIp,Date date
    ){
        this.applicationId=applicationId;
        this.errorCode =errorCode;
        this.errorSeverity  =errorSeverity;
        this.errorDescription = errorDescription;
        this.serverId = serverId;
        this.id = id;
        this.date = date;
        this.applicationName = applicationName;
        this.severIp = severIp;

    }


    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorSeverity() {
        return errorSeverity;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public int getServerId() {
        return serverId;
    }

    public int getApplicationId() {
        return applicationId;
    }

    public int getId() {
        return id;
    }

    public String getSeverIp() {
        return severIp;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public Date getDate() {
        return date;
    }



}
