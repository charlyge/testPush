package com.example.developer.testfirebasecloudmessaging;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.example.developer.testfirebasecloudmessaging.Entities.ServerIp;


public class DialogDetailsFragment extends DialogFragment {
    private static final String ERRORDESCRIPTION = "errorDes";
    private static final String TIMEDATE = "timeDate";
    private static final String APPNAME = "appNAME";
    private static final String ERRORCODE ="error code" ;
    private static final String SEVERITY_LEVEL = "severity level";
    private static final String SERVERIP ="seerriP" ;
    TextView errordescriptionTv,timeTv,appNameTv,severityLevelTv,errorCodeTv, severIpTv;
    String errordescription,time_Date,appName,severityLevel,errorCode,SerVerIp;
     private static int num = 88;
    public static final String TITLE = "Key";
    private static int mNum = 99;


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(ERRORDESCRIPTION,errordescription);
        outState.putString(TIMEDATE,time_Date);
        outState.putString(APPNAME,appName);
        outState.putString(SEVERITY_LEVEL,severityLevel);
        outState.putString(ERRORCODE,errorCode);
        outState.putString(SERVERIP,SerVerIp);

    }

    public DialogDetailsFragment(){}

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public void setErrordescription(String errordescription) {
        this.errordescription = errordescription;
    }


    public void setAppName(String appName) {
        this.appName = appName;
    }

    public void setTime_Date(String time_Date) {
        this.time_Date = time_Date;
    }

    public void setSeverityLevel(String severityLevel) {
        this.severityLevel = severityLevel;
    }

    public void setSerVerIp(String serVerIp) {
        SerVerIp = serVerIp;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        //If don't want toolbar
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        return dialog;

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if(savedInstanceState!=null){
            errordescription = savedInstanceState.getString(ERRORDESCRIPTION);
            severityLevel = savedInstanceState.getString(SEVERITY_LEVEL);
            errorCode = savedInstanceState.getString(ERRORCODE);
            appName = savedInstanceState.getString(APPNAME);
            time_Date = savedInstanceState.getString(TIMEDATE);
            SerVerIp = savedInstanceState.getString(SERVERIP);

        }
        View view = inflater.inflate(R.layout.error_log_details,container,false);
        errorCodeTv = view.findViewById(R.id.error_code_details);
        severityLevelTv = view.findViewById(R.id.severity_level_details);
        appNameTv = view.findViewById(R.id.app_name_details);
        timeTv = view.findViewById(R.id.time_date_details);
        errordescriptionTv = view.findViewById(R.id.error_des_details);
        severIpTv = view.findViewById(R.id.server_ip_details);

        errorCodeTv.setText(errorCode);
        severityLevelTv.setText(severityLevel);
        appNameTv.setText(appName);
        timeTv.setText(time_Date);
       errordescriptionTv.setText(errordescription);
       severIpTv.setText(SerVerIp);
        return view;
    }
}
