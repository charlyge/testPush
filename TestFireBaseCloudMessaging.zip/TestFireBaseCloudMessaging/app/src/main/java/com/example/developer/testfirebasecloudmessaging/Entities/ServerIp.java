package com.example.developer.testfirebasecloudmessaging.Entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

@Entity
public class ServerIp {

    @PrimaryKey(autoGenerate = true)
    private int sid;
    private String ServerName;
    private String serverStatus;


    @Ignore
    public ServerIp(String ServerName){
        this.ServerName = ServerName;

    }

    public ServerIp(int sid,String ServerName,String serverStatus){
        this.sid =sid;
        this.ServerName = ServerName;
        this.serverStatus =serverStatus;

    }

    @Ignore
    public ServerIp(String ServerName,String serverStatus){
        this.ServerName = ServerName;
        this.serverStatus =serverStatus;

    }

    public String getServerName() {
        return ServerName;
    }

    public String getServerStatus() {
        return serverStatus;
    }


    public void setServerName(String serverName) {
        ServerName = serverName;
    }

    public void setServerStatus(String serverStatus) {
        this.serverStatus = serverStatus;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getSid() {
        return sid;
    }
}
