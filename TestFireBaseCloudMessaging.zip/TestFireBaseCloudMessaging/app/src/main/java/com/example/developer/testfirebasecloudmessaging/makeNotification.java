package com.example.developer.testfirebasecloudmessaging;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.CHANNEL_ID;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.NOTIFICATIONID;

public class makeNotification {

    public static void sendNotification(Context context){
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent intent = new Intent(context.getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context.getApplicationContext(),0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder= new NotificationCompat.Builder(context.getApplicationContext(),CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notifications_active_black_24dp)
                .setContentTitle("Server Error Alert")
                .setContentIntent(pendingIntent)
                .setContentText("Text")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name ="Error Notification";
            // String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);

            notificationManager.createNotificationChannel(channel);

        }

        notificationManager.notify(NOTIFICATIONID,builder.build());

    }
}
