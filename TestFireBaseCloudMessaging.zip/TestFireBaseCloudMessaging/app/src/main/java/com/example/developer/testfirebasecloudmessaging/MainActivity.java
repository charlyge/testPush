package com.example.developer.testfirebasecloudmessaging;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.APPLICATION_NAME;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.ERROR_DESCRIPTION;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.ERROR_SEVERITY;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.SERVER_IP;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView serverIpTv = findViewById(R.id.server_ip);
        TextView errorDescTv = findViewById(R.id.error_description);
        TextView appNameTv = findViewById(R.id.application_name);
        TextView severityLevelTv = findViewById(R.id.severity_level);

        FirebaseMessaging.getInstance().subscribeToTopic("Error").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Log.i("Sucess","Sucess");
                }else {
                    Log.i("failure","failure");
                }


            }
        });

        Intent intent = getIntent();
    if(intent!=null){
        Toast.makeText(this,"intent not null" ,Toast.LENGTH_LONG).show();
    }
    else {
        Toast.makeText(this,"intent is null" ,Toast.LENGTH_LONG).show();
    }
        if(intent.hasExtra(SERVER_IP)){
         String server_ip = intent.getStringExtra(SERVER_IP);
          serverIpTv.setText(server_ip);

        }


        if (intent.hasExtra(APPLICATION_NAME)){
         String applicationName = intent.getStringExtra(APPLICATION_NAME);
         appNameTv.setText(applicationName);

        }
        if(intent.hasExtra(ERROR_SEVERITY)){
          String errorServ = intent.getStringExtra(ERROR_SEVERITY);
          severityLevelTv.setText(errorServ);

        }

        if(intent.hasExtra(ERROR_DESCRIPTION)){
       String error_descvription = intent.getStringExtra(ERROR_DESCRIPTION);
       errorDescTv.setText(error_descvription);

        }

    }
}
