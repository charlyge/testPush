package com.example.developer.testfirebasecloudmessaging;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.developer.testfirebasecloudmessaging.Database.AppDatabase;
import com.example.developer.testfirebasecloudmessaging.Database.AppExecutors;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.APPLICATION_NAME;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.ERROR_DESCRIPTION;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.ERROR_SEVERITY;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.SERVER_IP;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.cancelDispatcher;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        cancelDispatcher();
        FirebaseMessaging.getInstance().subscribeToTopic("Error").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Log.i("Sucess","Sucess");
                }else {
                    Log.i("failure","failure");
                }


            }
        });

        Intent intent = getIntent();
    if(intent!=null){
        Toast.makeText(this,"intent not null" ,Toast.LENGTH_LONG).show();
    }
    else {
        Toast.makeText(this,"intent is null" ,Toast.LENGTH_LONG).show();
    }
        if(intent.hasExtra(SERVER_IP)){

        }

    }

    public void gotoViewErrorLog(View view) {
        Intent intent = new Intent(this,ViewErrorActivity.class);
        startActivity(intent);
    }

    public void clearErrorLog(View view) {
        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
            @Override
            public void run() {
                AppDatabase.getInstance(MainActivity.this).errorNotifiedDAO().DeleteAll();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,"All Error Logs Deleted",Toast.LENGTH_LONG).show();
                    }
                });

            }
        });

    }
}
