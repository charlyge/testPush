package com.example.developer.testfirebasecloudmessaging;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.example.developer.testfirebasecloudmessaging.Database.AppDatabase;
import com.example.developer.testfirebasecloudmessaging.Database.AppExecutors;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.SERVER_IP;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.cancelDispatcher;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                String token = task.getResult().getToken();
                Log.i("Token", token);

            }
        });

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        final String topic = sharedPreferences.getString(getString(R.string.edit_key), getString(R.string.edit_value));
        assert topic != null;
        FirebaseMessaging.getInstance().subscribeToTopic(topic).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {

                    sendNewTopictoServer(topic);

                    Log.i("Sucess", "Sucess");
                } else {
                    Log.i("failure", "failure");
                }


            }
        });

        Intent intent = getIntent();

        if (intent.hasExtra(SERVER_IP)) {
            cancelDispatcher();

        }

    }

    public void gotoViewErrorLog(View view) {
        Intent intent = new Intent(this, ViewErrorActivity.class);
        startActivity(intent);
    }

   public void clearErrorLog(View view) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_dialog);
        dialog.show();


        Button bt_yes = (Button) dialog.findViewById(R.id.buttonYes);
        Button bt_no = (Button) dialog.findViewById(R.id.buttonNo);

        bt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        AppDatabase.getInstance(MainActivity.this).errorNotifiedDAO().DeleteAll();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "All Error Logs Deleted", Toast.LENGTH_LONG).show();
                            }
                        });

                    }
                });
            }
        });
        bt_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.subscribe_to_topic, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.resub_to_topic) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void sendNewTopictoServer(String topic) {


    }


    //Refreshes Users Token
    public void refreshToken(View view) {

        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
            @Override
            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                String token = task.getResult().getToken();
                Log.i("Token is ", token);

                sendNewTokenToServer(token);
            }
        });
    }

    //Updates Server with new Token
    private void sendNewTokenToServer(String token) {

    }
}
