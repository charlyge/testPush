package com.example.developer.testfirebasecloudmessaging.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.developer.testfirebasecloudmessaging.Entities.AppName;

import java.util.List;

@Dao
public interface AppNameDAO {
    @Insert
    long insertAppName(AppName appName);

    @Query("Select * from  AppName")
    List<AppName> getAllAppName();

    @Query("Select Appid from AppName where ApplicationName = :appName")
    int getAppIdFromName(String appName);

    @Query("Select * from AppName where Appid = :appNam")
    List<AppName> getAllAppNameById(int appNam);


}
