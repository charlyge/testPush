package com.example.developer.testfirebasecloudmessaging.fcm;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.example.developer.testfirebasecloudmessaging.MainActivity;
import com.example.developer.testfirebasecloudmessaging.R;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.CHANNEL_ID;
import static com.example.developer.testfirebasecloudmessaging.fcm.FirebaseMessageCloud.NOTIFICATIONID;
import static com.example.developer.testfirebasecloudmessaging.makeNotification.sendNotification;

public class MyJobservice extends JobService {


    @Override
    public boolean onStartJob(JobParameters job) {
        Log.d("jobsMyy started","jobs started");
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        Ringtone ringtone = RingtoneManager.getRingtone(getApplicationContext(),alarmSound);
        ringtone.play();
        jobFinished(job,false);
        Log.d("jobsMyy started","jobs started");
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        return true;
    }
}
