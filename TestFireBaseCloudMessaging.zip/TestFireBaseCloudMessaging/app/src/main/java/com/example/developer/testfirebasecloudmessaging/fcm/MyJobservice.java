package com.example.developer.testfirebasecloudmessaging.fcm;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;

import android.util.Log;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

public class MyJobservice extends JobService {


    @Override
    public boolean onStartJob(JobParameters job) {
        Log.i("jobsMyy started","jobs started");
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        Ringtone ringtone = RingtoneManager.getRingtone(this,alarmSound);
        ringtone.play();
        jobFinished(job,false);
        Log.i("jobsMyy started","jobs started");
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        return false;
    }
}
