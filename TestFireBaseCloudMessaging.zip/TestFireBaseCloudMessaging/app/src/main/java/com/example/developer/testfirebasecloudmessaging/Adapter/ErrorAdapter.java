package com.example.developer.testfirebasecloudmessaging.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.developer.testfirebasecloudmessaging.Database.AppExecutors;
import com.example.developer.testfirebasecloudmessaging.Entities.ErrorNotified;
import com.example.developer.testfirebasecloudmessaging.R;

import java.util.ArrayList;
import java.util.List;

public class ErrorAdapter extends RecyclerView.Adapter<ErrorAdapter.MyViewHolder> {
   private List<ErrorNotified> errorNotifiedList;

  public ErrorAdapter( List<ErrorNotified> errorNotifiedList){
      this.errorNotifiedList =errorNotifiedList;

  }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context = viewGroup.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.error_list_item,viewGroup,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        ErrorNotified errorNotified = errorNotifiedList.get(myViewHolder.getAdapterPosition());
        String serverId = errorNotified.getSeverIp();
         String applicationId = errorNotified.getApplicationName();
         String errorCode = errorNotified.getErrorCode();
         String errorDescription = errorNotified.getErrorDescription();
         String errorSeverity = errorNotified.getErrorSeverity();
         myViewHolder.SeverityLevelTv.setText(errorSeverity);
         myViewHolder.appIdTv.setText(String.valueOf(applicationId));
         myViewHolder.ErrocodeTv.setText(errorCode);
         myViewHolder.errorDescTv.setText(errorDescription);
         myViewHolder.severIdTv.setText(String.valueOf(serverId));
    }

    @Override
    public int getItemCount() {
        if(errorNotifiedList ==null){
            return 0;
        }
      return errorNotifiedList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView errorDescTv,ErrocodeTv,SeverityLevelTv,appIdTv,severIdTv;
        MyViewHolder(@NonNull View itemView) {

            super(itemView);
            errorDescTv = itemView.findViewById(R.id.error_description);
            ErrocodeTv = itemView.findViewById(R.id.error_code_tv);
            SeverityLevelTv = itemView.findViewById(R.id.severity_level);
            severIdTv = itemView.findViewById(R.id.server_id);
            appIdTv = itemView.findViewById(R.id.application_id);

        }
    }

    public void setErrorNotifiedList(List<ErrorNotified> errorNotifiedList) {
            this.errorNotifiedList = errorNotifiedList;
            notifyDataSetChanged();


    }
}
