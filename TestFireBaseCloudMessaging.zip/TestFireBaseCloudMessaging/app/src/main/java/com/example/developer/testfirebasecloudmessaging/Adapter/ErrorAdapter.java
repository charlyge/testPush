package com.example.developer.testfirebasecloudmessaging.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

import com.example.developer.testfirebasecloudmessaging.Model.ErrorLog;

import java.util.List;

public class ErrorAdapter extends RecyclerView.Adapter<ErrorAdapter.MyViewHolder> {
  List<ErrorLog> errorLogList;

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        if(errorLogList==null){
            return 0;
        }
      return errorLogList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
