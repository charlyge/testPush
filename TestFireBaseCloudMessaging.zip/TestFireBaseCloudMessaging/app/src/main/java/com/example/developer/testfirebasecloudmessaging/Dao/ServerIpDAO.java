package com.example.developer.testfirebasecloudmessaging.Dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.developer.testfirebasecloudmessaging.Entities.ServerIp;

import java.util.List;

@Dao
public interface ServerIpDAO {
    @Insert
    long insertServerIP(ServerIp serverIp);

    @Query("Select * from  ServerIp")
    List<ServerIp> getAllServerIp();

    @Query("Select sid from ServerIp where ServerName = :serverName")
    int getServerIdFromName(String serverName);

}
