package com.example.developer.testfirebasecloudmessaging;

import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.developer.testfirebasecloudmessaging.Adapter.ErrorAdapter;
import com.example.developer.testfirebasecloudmessaging.Database.AppDatabase;
import com.example.developer.testfirebasecloudmessaging.Database.AppExecutors;
import com.example.developer.testfirebasecloudmessaging.Entities.AppName;
import com.example.developer.testfirebasecloudmessaging.Entities.ErrorNotified;
import com.example.developer.testfirebasecloudmessaging.Entities.ServerIp;

import java.util.ArrayList;
import java.util.List;

import static android.support.v7.widget.LinearLayoutManager.VERTICAL;

public class ViewErrorActivity extends AppCompatActivity implements ErrorAdapter.itemClickListener {
    RecyclerView recyclerView;
    ErrorAdapter  errorAdapter;
    List<ErrorNotified> errorNotifiedList;
    AppDatabase appDatabase;
    Spinner appNamespinner;
    private Spinner serverIpspinner;
    TextView noRecordFoundTv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_error);
         recyclerView = findViewById(R.id.recycler_view_error);
         appDatabase = AppDatabase.getInstance(getApplicationContext());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        errorAdapter = new ErrorAdapter(errorNotifiedList,this);
        recyclerView.setLayoutManager(linearLayoutManager);
        serverIpspinner = (Spinner) findViewById(R.id.server_spinner_label);
       appNamespinner= (Spinner) findViewById(R.id.app_name_spinner);
       noRecordFoundTv = findViewById(R.id.no_record_found);
        recyclerView.setHasFixedSize(true);
        DividerItemDecoration decoration = new DividerItemDecoration(getApplicationContext(), VERTICAL);
        recyclerView.addItemDecoration(decoration);
        recyclerView.setAdapter(errorAdapter);


                new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {

                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull final RecyclerView.ViewHolder viewHolder, int i) {
                        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                            @Override
                            public void run() {
                                int position = viewHolder.getAdapterPosition();
                                ErrorNotified errorNotifiedList = appDatabase.errorNotifiedDAO().getAllErrorLogs().get(position);

                                appDatabase.errorNotifiedDAO().deleteErrorLogs(errorNotifiedList);
                                populateUi();
                            }
                        });


                    }
                }).attachToRecyclerView(recyclerView);
                populateUi();
                setUpServerIpSpinner();
                setUpAppNameSpinner();
            }

    private void setUpAppNameSpinner() {

                final ArrayList<String> finalStringArrayList = new ArrayList<>();
                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        List<AppName> serverIpArrayList = appDatabase.appNameDAO().getAllAppName();
                        for (int i = 0; i < serverIpArrayList.size(); i++) {

                            String AppName = serverIpArrayList.get(i).getApplicationName();
                            finalStringArrayList.add(AppName);

                        }
                        final ArrayAdapter adapter = new ArrayAdapter(ViewErrorActivity.this, android.R.layout.simple_spinner_item, finalStringArrayList);

                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                appNamespinner.setAdapter(adapter);
                            }
                        });


                    }
                });
            }

            private void setUpServerIpSpinner() {


                final ArrayList<String> finalStringArrayList = new ArrayList<>();
                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        List<ServerIp> serverIpArrayList = appDatabase.serverIpDAO().getAllServerIp();
                        for (int i = 0; i < serverIpArrayList.size(); i++) {

                            String serverName = serverIpArrayList.get(i).getServerName();
                            finalStringArrayList.add(serverName);

                        }
                        final ArrayAdapter adapter = new ArrayAdapter(ViewErrorActivity.this, android.R.layout.simple_spinner_item, finalStringArrayList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                serverIpspinner.setAdapter(adapter);
                            }
                        });



                    }
                });


            }

            public void populateUi() {
                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                      errorNotifiedList = appDatabase.errorNotifiedDAO().getAllErrorLogs();
                        // Log.i("errorLogs",errorNotifiedList.get(0).getErrorDescription());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //   Log.i("errorLogs",errorNotifiedList.get(0).getErrorDescription());
                                errorAdapter.setErrorNotifiedList(errorNotifiedList);
                            }
                        });

                    }
                });


            }

            public void searchDb(View view) {
        noRecordFoundTv.setVisibility(View.GONE);

                Spinner spinner = findViewById(R.id.server_spinner_label);

                final String item = spinner.getSelectedItem().toString();

                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                 errorNotifiedList = appDatabase.errorNotifiedDAO().getAllSeverIp(item);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                errorAdapter.setErrorNotifiedList(errorNotifiedList);
                            }
                        });

                    }
                });
            }


    /*public void searchDbByName(View view) {
        noRecordFoundTv.setVisibility(View.GONE);
        Spinner spinner = findViewById(R.id.app_name_spinner);

        final String item = spinner.getSelectedItem().toString();

        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
            @Override
            public void run() {
                final List<ErrorNotified> errorNotifiedList = appDatabase.errorNotifiedDAO().getAllSeverName(item);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        errorAdapter.setErrorNotifiedList(errorNotifiedList);
                    }
                });

            }
        });
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
      getMenuInflater().inflate(R.menu.search_all,menu);
      return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.refresh){
            noRecordFoundTv.setVisibility(View.GONE);
            populateUi();
            Toast.makeText(ViewErrorActivity.this,"Showing all Error Logs",Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void searchByIpandName(View view) {

        final String serverIpSpinnerItem = serverIpspinner.getSelectedItem().toString();
        final String AppNameSpinneritem = appNamespinner.getSelectedItem().toString();
        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
            @Override
            public void run() {
            errorNotifiedList = appDatabase.errorNotifiedDAO().
                       getAllSeverNameAndIp(AppNameSpinneritem,serverIpSpinnerItem);
               runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                       Log.i("listData",errorNotifiedList.toString());
                       if(errorNotifiedList==null || errorNotifiedList.isEmpty()){
                           noRecordFoundTv.setVisibility(View.VISIBLE);
                       }else {
                           noRecordFoundTv.setVisibility(View.GONE);
                           errorAdapter.setErrorNotifiedList(errorNotifiedList);
                       }

                   }
               });

            }
        });
    }

    @Override
    public void onItemClicked(String serverId, String applicationId, String errorCode, String errorDescription, String updatedAt, String errorSeverity) {
  Toast.makeText(this,"click click",Toast.LENGTH_LONG).show();
        // DialogFragment.show() will take care of adding the fragment
        // in a transaction.  We also want to remove any currently showing
        // dialog, so make our own transaction and take care of that here.

        // Create and show the dialog.
        DialogFragment newFragment = new DialogDetailsFragment();
       ((DialogDetailsFragment) newFragment).setAppName(applicationId);
        ((DialogDetailsFragment) newFragment).setErrorCode(errorCode);
        ((DialogDetailsFragment) newFragment).setSerVerIp(serverId);
        ((DialogDetailsFragment) newFragment).setErrordescription(errorDescription);
        ((DialogDetailsFragment) newFragment).setSeverityLevel(errorSeverity);
        ((DialogDetailsFragment) newFragment).setTime_Date(updatedAt);

       newFragment.show(getSupportFragmentManager(), "dialog");
    }



}