package com.example.developer.testfirebasecloudmessaging;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Spinner;

import com.example.developer.testfirebasecloudmessaging.Adapter.ErrorAdapter;
import com.example.developer.testfirebasecloudmessaging.Database.AppDatabase;
import com.example.developer.testfirebasecloudmessaging.Database.AppExecutors;
import com.example.developer.testfirebasecloudmessaging.Entities.AppName;
import com.example.developer.testfirebasecloudmessaging.Entities.ErrorNotified;
import com.example.developer.testfirebasecloudmessaging.Entities.ServerIp;

import java.util.ArrayList;
import java.util.List;

import static android.support.v7.widget.LinearLayoutManager.VERTICAL;

public class ViewErrorActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ErrorAdapter  errorAdapter;
    List<ErrorNotified> errorNotifiedList;
    AppDatabase appDatabase;
    CheckBox checkBox;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_error);
         recyclerView = findViewById(R.id.recycler_view_error);
         appDatabase = AppDatabase.getInstance(getApplicationContext());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        errorAdapter = new ErrorAdapter(errorNotifiedList);
        recyclerView.setLayoutManager(linearLayoutManager);
       spinner= (Spinner) findViewById(R.id.app_name_spinner);
        recyclerView.setHasFixedSize(true);
        DividerItemDecoration decoration = new DividerItemDecoration(getApplicationContext(), VERTICAL);
        recyclerView.addItemDecoration(decoration);
        recyclerView.setAdapter(errorAdapter);
        checkBox =findViewById(R.id.select_all_ckbox);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    populateUi();
                    //checkBox.setChecked(false);

                }
            }
        });

                new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {

                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull final RecyclerView.ViewHolder viewHolder, int i) {
                        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                            @Override
                            public void run() {
                                int position = viewHolder.getAdapterPosition();
                                ErrorNotified errorNotifiedList = appDatabase.errorNotifiedDAO().getAllErrorLogs().get(position);

                                appDatabase.errorNotifiedDAO().deleteErrorLogs(errorNotifiedList);
                                populateUi();
                            }
                        });


                    }
                }).attachToRecyclerView(recyclerView);
                populateUi();
                setUpServerIpSpinner();
                setUpAppNameSpinner();
            }

            private void setUpAppNameSpinner() {

                final ArrayList<String> finalStringArrayList = new ArrayList<>();
                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        List<AppName> serverIpArrayList = appDatabase.appNameDAO().getAllAppName();
                        for (int i = 0; i < serverIpArrayList.size(); i++) {

                            String AppName = serverIpArrayList.get(i).getApplicationName();
                            finalStringArrayList.add(AppName);

                        }
                        ArrayAdapter adapter = new ArrayAdapter(ViewErrorActivity.this, android.R.layout.simple_spinner_item, finalStringArrayList);

                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner.setAdapter(adapter);


                    }
                });
            }

            private void setUpServerIpSpinner() {

                final Spinner spinner = (Spinner) findViewById(R.id.server_spinner_label);
                final ArrayList<String> finalStringArrayList = new ArrayList<>();
                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        List<ServerIp> serverIpArrayList = appDatabase.serverIpDAO().getAllServerIp();
                        for (int i = 0; i < serverIpArrayList.size(); i++) {

                            String serverName = serverIpArrayList.get(i).getServerName();
                            finalStringArrayList.add(serverName);

                        }
                        ArrayAdapter adapter = new ArrayAdapter(ViewErrorActivity.this, android.R.layout.simple_spinner_item, finalStringArrayList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner.setAdapter(adapter);


                    }
                });


            }

            public void populateUi() {
                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        final List<ErrorNotified> errorNotifiedList = appDatabase.errorNotifiedDAO().getAllErrorLogs();
                        // Log.i("errorLogs",errorNotifiedList.get(0).getErrorDescription());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //   Log.i("errorLogs",errorNotifiedList.get(0).getErrorDescription());
                                errorAdapter.setErrorNotifiedList(errorNotifiedList);
                            }
                        });

                    }
                });


            }

            public void searchDb(View view) {

                Spinner spinner = findViewById(R.id.server_spinner_label);

                final String item = spinner.getSelectedItem().toString();

                AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        final List<ErrorNotified> errorNotifiedList = appDatabase.errorNotifiedDAO().getAllSeverIp(item);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                errorAdapter.setErrorNotifiedList(errorNotifiedList);
                            }
                        });

                    }
                });
            }


    public void searchDbByName(View view) {
        Spinner spinner = findViewById(R.id.app_name_spinner);

        final String item = spinner.getSelectedItem().toString();

        AppExecutors.getInstance().getDiskIO().execute(new Runnable() {
            @Override
            public void run() {
                final List<ErrorNotified> errorNotifiedList = appDatabase.errorNotifiedDAO().getAllSeverName(item);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        errorAdapter.setErrorNotifiedList(errorNotifiedList);
                    }
                });

            }
        });
    }
}